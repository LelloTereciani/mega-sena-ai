import * as tf from '@tensorflow/tfjs';
import type { Draw } from '../../../drizzle/schema';

/**
 * 1. Regressão Linear - Analisa tendências de frequência ao longo do tempo
 */
export function linearRegression(draws: Draw[]): Map<number, number> {
  const scores = new Map<number, number>();
  
  // Para cada número de 1 a 60
  for (let num = 1; num <= 60; num++) {
    const appearances: number[] = [];
    
    // Encontrar índices onde o número aparece
    draws.forEach((draw, index) => {
      const balls = [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6];
      if (balls.includes(num)) {
        appearances.push(index);
      }
    });
    
    if (appearances.length < 2) {
      scores.set(num, 0);
      continue;
    }
    
    // Calcular tendência (regressão linear simples)
    const n = appearances.length;
    const sumX = appearances.reduce((a, b) => a + b, 0);
    const sumY = Array.from({ length: n }, (_, i) => i + 1).reduce((a, b) => a + b, 0);
    const sumXY = appearances.reduce((sum, x, i) => sum + x * (i + 1), 0);
    const sumX2 = appearances.reduce((sum, x) => sum + x * x, 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    
    // Slope positivo = tendência crescente (número aparecendo mais recentemente)
    scores.set(num, slope * 100);
  }
  
  return scores;
}

/**
 * 2. Clustering K-means - Agrupa números por padrões de aparição
 */
export function kMeansClustering(draws: Draw[], k: number = 3): Map<number, number> {
  const scores = new Map<number, number>();
  
  // Criar vetor de características para cada número
  const features: number[][] = [];
  const numbers: number[] = [];
  
  for (let num = 1; num <= 60; num++) {
    let frequency = 0;
    let lastSeen = draws.length;
    let avgGap = 0;
    const gaps: number[] = [];
    
    draws.forEach((draw, index) => {
      const balls = [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6];
      if (balls.includes(num)) {
        frequency++;
        if (lastSeen < draws.length) {
          gaps.push(index - lastSeen);
        }
        lastSeen = index;
      }
    });
    
    if (gaps.length > 0) {
      avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    }
    
    // Normalizar características
    const normalizedFreq = frequency / draws.length;
    const normalizedGap = avgGap / draws.length;
    const normalizedRecency = (draws.length - lastSeen) / draws.length;
    
    features.push([normalizedFreq, normalizedGap, normalizedRecency]);
    numbers.push(num);
  }
  
  // K-means simples (3 clusters: quente, neutro, frio)
  const clusters = simpleKMeans(features, k);
  
  // Identificar qual cluster é o "quente" (maior frequência média)
  const clusterStats = new Map<number, { count: number; totalFreq: number }>();
  clusters.forEach((cluster, index) => {
    if (!clusterStats.has(cluster)) {
      clusterStats.set(cluster, { count: 0, totalFreq: 0 });
    }
    const stats = clusterStats.get(cluster)!;
    stats.count++;
    stats.totalFreq += features[index][0];
  });
  
  const clusterScores = new Map<number, number>();
  clusterStats.forEach((stats, cluster) => {
    clusterScores.set(cluster, stats.totalFreq / stats.count);
  });
  
  // Atribuir scores baseados no cluster
  clusters.forEach((cluster, index) => {
    const clusterScore = clusterScores.get(cluster) || 0;
    scores.set(numbers[index], clusterScore * 100);
  });
  
  return scores;
}

/**
 * K-means simples
 */
function simpleKMeans(data: number[][], k: number): number[] {
  const n = data.length;
  const dim = data[0].length;
  
  // Inicializar centroides aleatoriamente
  const centroids: number[][] = [];
  for (let i = 0; i < k; i++) {
    centroids.push([...data[Math.floor(Math.random() * n)]]);
  }
  
  let clusters: number[] = new Array(n).fill(0);
  let changed = true;
  let iterations = 0;
  const maxIterations = 100;
  
  while (changed && iterations < maxIterations) {
    changed = false;
    iterations++;
    
    // Atribuir pontos aos clusters mais próximos
    for (let i = 0; i < n; i++) {
      let minDist = Infinity;
      let bestCluster = 0;
      
      for (let j = 0; j < k; j++) {
        const dist = euclideanDistance(data[i], centroids[j]);
        if (dist < minDist) {
          minDist = dist;
          bestCluster = j;
        }
      }
      
      if (clusters[i] !== bestCluster) {
        clusters[i] = bestCluster;
        changed = true;
      }
    }
    
    // Atualizar centroides
    for (let j = 0; j < k; j++) {
      const clusterPoints = data.filter((_, i) => clusters[i] === j);
      if (clusterPoints.length > 0) {
        for (let d = 0; d < dim; d++) {
          centroids[j][d] = clusterPoints.reduce((sum, p) => sum + p[d], 0) / clusterPoints.length;
        }
      }
    }
  }
  
  return clusters;
}

function euclideanDistance(a: number[], b: number[]): number {
  return Math.sqrt(a.reduce((sum, val, i) => sum + Math.pow(val - b[i], 2), 0));
}

/**
 * 3. Rede Neural - Predição usando TensorFlow.js
 */
export async function neuralNetworkPrediction(draws: Draw[]): Promise<Map<number, number>> {
  const scores = new Map<number, number>();
  
  try {
    // Preparar dados de treino
    const windowSize = 10; // Últimos 10 sorteios
    const trainingData: number[][] = [];
    const labels: number[][] = [];
    
    for (let i = windowSize; i < draws.length; i++) {
      const window: number[] = [];
      
      // Criar vetor de entrada (últimos 10 sorteios)
      for (let j = i - windowSize; j < i; j++) {
        const draw = draws[j];
        const balls = [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6];
        balls.forEach(ball => window.push(ball / 60)); // Normalizar
      }
      
      // Label: próximo sorteio
      const nextDraw = draws[i];
      const nextBalls = [nextDraw.ball1, nextDraw.ball2, nextDraw.ball3, nextDraw.ball4, nextDraw.ball5, nextDraw.ball6];
      const label = new Array(60).fill(0);
      nextBalls.forEach(ball => label[ball - 1] = 1);
      
      trainingData.push(window);
      labels.push(label);
    }
    
    if (trainingData.length === 0) {
      // Fallback: retornar scores baseados em frequência
      draws.forEach(draw => {
        [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6].forEach(ball => {
          scores.set(ball, (scores.get(ball) || 0) + 1);
        });
      });
      return scores;
    }
    
    // Criar modelo
    const model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [windowSize * 6], units: 128, activation: 'relu' }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.dense({ units: 64, activation: 'relu' }),
        tf.layers.dense({ units: 60, activation: 'sigmoid' }),
      ],
    });
    
    model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'binaryCrossentropy',
      metrics: ['accuracy'],
    });
    
    // Converter para tensores
    const xs = tf.tensor2d(trainingData);
    const ys = tf.tensor2d(labels);
    
    // Treinar (poucas épocas para não travar)
    await model.fit(xs, ys, {
      epochs: 5,
      batchSize: 32,
      verbose: 0,
    });
    
    // Fazer predição para próximo sorteio
    const lastWindow: number[] = [];
    for (let i = draws.length - windowSize; i < draws.length; i++) {
      const draw = draws[i];
      [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6].forEach(ball => {
        lastWindow.push(ball / 60);
      });
    }
    
    const prediction = model.predict(tf.tensor2d([lastWindow])) as tf.Tensor;
    const predictionArray = await prediction.data();
    
    // Converter predições em scores
    predictionArray.forEach((score, index) => {
      scores.set(index + 1, score * 100);
    });
    
    // Limpar memória
    xs.dispose();
    ys.dispose();
    prediction.dispose();
    model.dispose();
    
  } catch (error) {
    console.error('Erro na rede neural:', error);
    // Fallback
    draws.forEach(draw => {
      [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6].forEach(ball => {
        scores.set(ball, (scores.get(ball) || 0) + 1);
      });
    });
  }
  
  return scores;
}

/**
 * 4. Regressão Logística - Classificação de números quentes/frios
 */
export function logisticRegression(draws: Draw[]): Map<number, number> {
  const scores = new Map<number, number>();
  const recentWindow = 100; // Últimos 100 sorteios
  const recentDraws = draws.slice(0, Math.min(recentWindow, draws.length));
  
  for (let num = 1; num <= 60; num++) {
    let recentCount = 0;
    let totalCount = 0;
    
    recentDraws.forEach(draw => {
      const balls = [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6];
      if (balls.includes(num)) recentCount++;
    });
    
    draws.forEach(draw => {
      const balls = [draw.ball1, draw.ball2, draw.ball3, draw.ball4, draw.ball5, draw.ball6];
      if (balls.includes(num)) totalCount++;
    });
    
    // Probabilidade recente vs histórica
    const recentProb = recentCount / recentDraws.length;
    const totalProb = totalCount / draws.length;
    
    // Logistic function
    const z = (recentProb - totalProb) * 10;
    const sigmoid = 1 / (1 + Math.exp(-z));
    
    scores.set(num, sigmoid * 100);
  }
  
  return scores;
}

/**
 * Combinar todas as técnicas de IA
 */
export async function combinedAIScore(draws: Draw[]): Promise<Map<number, number>> {
  const regression = linearRegression(draws);
  const clustering = kMeansClustering(draws);
  const logistic = logisticRegression(draws);
  const neural = await neuralNetworkPrediction(draws);
  
  const combined = new Map<number, number>();
  
  for (let num = 1; num <= 60; num++) {
    const score =
      (regression.get(num) || 0) * 0.25 +
      (clustering.get(num) || 0) * 0.25 +
      (logistic.get(num) || 0) * 0.25 +
      (neural.get(num) || 0) * 0.25;
    
    combined.set(num, score);
  }
  
  return combined;
}
