import type { Draw } from '../../../drizzle/schema';
import {
  calculateFrequency,
  calculateGaps,
  classifyHotCold,
  analyzeDistribution,
  calculateHistoricalDistribution,
  type NumberFrequency,
  type GapAnalysis,
  type HotColdNumber,
} from './analytics';

export interface GameFilters {
  // Paridade
  minEven?: number;
  maxEven?: number;
  
  // Distribuição alta/baixa
  minLow?: number;
  maxLow?: number;
  
  // Sequências
  allowConsecutive?: boolean;
  maxConsecutive?: number;
  
  // Soma
  minSum?: number;
  maxSum?: number;
  
  // Primos
  minPrimes?: number;
  maxPrimes?: number;
  
  // Múltiplos
  excludeMultiplesOf?: number[];
  
  // Números fixos
  includeNumbers?: number[];
  excludeNumbers?: number[];
  
  // Temperatura
  minHot?: number;
  maxCold?: number;
  
  // Distribuição no volante (linhas/colunas)
  balanceGrid?: boolean;
}

export interface GenerationStrategy {
  name: string;
  description: string;
  weights: {
    frequency: number;
    gap: number;
    trend: number;
    temperature: number;
  };
}

export const strategies: Record<string, GenerationStrategy> = {
  statistical: {
    name: 'Estatística Clássica',
    description: 'Baseado em frequência e distribuição histórica',
    weights: { frequency: 0.6, gap: 0.3, trend: 0.1, temperature: 0 },
  },
  regression: {
    name: 'Regressão Linear',
    description: 'Analisa tendências de frequência ao longo do tempo usando regressão',
    weights: { frequency: 0.3, gap: 0.2, trend: 0.4, temperature: 0.1 },
  },
  clustering: {
    name: 'Clustering K-means',
    description: 'Agrupa números por padrões de aparição usando machine learning',
    weights: { frequency: 0.25, gap: 0.25, trend: 0.25, temperature: 0.25 },
  },
  logistic: {
    name: 'Regressão Logística',
    description: 'Classificação probabilística de números quentes/frios',
    weights: { frequency: 0.2, gap: 0.2, trend: 0.3, temperature: 0.3 },
  },
  neural: {
    name: 'Rede Neural (IA)',
    description: 'Predição avançada usando deep learning com TensorFlow.js',
    weights: { frequency: 0.2, gap: 0.2, trend: 0.3, temperature: 0.3 },
  },
};

/**
 * Gera um jogo baseado em estratégia e filtros
 */
export function generateGame(
  draws: Draw[],
  strategy: GenerationStrategy,
  filters: GameFilters = {}
): number[] {
  const frequency = calculateFrequency(draws);
  const gaps = calculateGaps(draws);
  const hotCold = classifyHotCold(draws);
  
  // Calculate scores for each number
  const scores = new Map<number, number>();
  
  for (let num = 1; num <= 60; num++) {
    // Skip excluded numbers
    if (filters.excludeNumbers?.includes(num)) continue;
    
    const freq = frequency.find(f => f.number === num)!;
    const gap = gaps.find(g => g.number === num)!;
    const temp = hotCold.find(h => h.number === num)!;
    
    // Normalize scores (0-1)
    const freqScore = freq.count / Math.max(...frequency.map(f => f.count));
    const gapScore = gap.isOverdue ? 1 : gap.currentGap / gap.averageGap;
    const trendScore = 0.5; // Simplified for now
    const tempScore = temp.temperature === 'hot' ? 1 : temp.temperature === 'cold' ? 0 : 0.5;
    
    // Weighted sum
    const totalScore = 
      freqScore * strategy.weights.frequency +
      gapScore * strategy.weights.gap +
      trendScore * strategy.weights.trend +
      tempScore * strategy.weights.temperature;
    
    scores.set(num, totalScore);
  }
  
  // Select numbers
  let candidates = Array.from(scores.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([num]) => num);
  
  // Add fixed numbers first
  const selected: number[] = [...(filters.includeNumbers || [])];
  candidates = candidates.filter(n => !selected.includes(n));
  
  // Select remaining numbers with validation
  let attempts = 0;
  const maxAttempts = 1000;
  
  while (selected.length < 6 && attempts < maxAttempts) {
    const game = [...selected];
    
    // Add top candidates
    for (const num of candidates) {
      if (game.length >= 6) break;
      if (!game.includes(num)) {
        game.push(num);
      }
    }
    
    // Validate against filters
    if (validateGame(game, filters, draws)) {
      return game.sort((a, b) => a - b);
    }
    
    // Shuffle candidates for next attempt
    candidates = shuffleArray(candidates);
    attempts++;
  }
  
  // Fallback: return top 6 if validation fails
  return [...selected, ...candidates.slice(0, 6 - selected.length)]
    .slice(0, 6)
    .sort((a, b) => a - b);
}

/**
 * Valida um jogo contra os filtros
 */
export function validateGame(game: number[], filters: GameFilters, draws: Draw[]): boolean {
  if (game.length !== 6) return false;
  
  const dist = analyzeDistribution(game);
  const hotCold = classifyHotCold(draws);
  
  // Paridade
  if (filters.minEven !== undefined && dist.even < filters.minEven) return false;
  if (filters.maxEven !== undefined && dist.even > filters.maxEven) return false;
  
  // Distribuição alta/baixa
  if (filters.minLow !== undefined && dist.low < filters.minLow) return false;
  if (filters.maxLow !== undefined && dist.low > filters.maxLow) return false;
  
  // Sequências consecutivas
  if (!filters.allowConsecutive || filters.maxConsecutive !== undefined) {
    const sorted = [...game].sort((a, b) => a - b);
    let consecutive = 1;
    let maxConsec = 1;
    
    for (let i = 1; i < sorted.length; i++) {
      if (sorted[i] === sorted[i - 1] + 1) {
        consecutive++;
        maxConsec = Math.max(maxConsec, consecutive);
      } else {
        consecutive = 1;
      }
    }
    
    if (!filters.allowConsecutive && maxConsec > 2) return false;
    if (filters.maxConsecutive !== undefined && maxConsec > filters.maxConsecutive) return false;
  }
  
  // Soma
  if (filters.minSum !== undefined && dist.sum < filters.minSum) return false;
  if (filters.maxSum !== undefined && dist.sum > filters.maxSum) return false;
  
  // Primos
  if (filters.minPrimes !== undefined && dist.primes < filters.minPrimes) return false;
  if (filters.maxPrimes !== undefined && dist.primes > filters.maxPrimes) return false;
  
  // Múltiplos
  if (filters.excludeMultiplesOf) {
    for (const mult of filters.excludeMultiplesOf) {
      const count = game.filter(n => n % mult === 0).length;
      if (count > 2) return false; // Max 2 multiples of any number
    }
  }
  
  // Temperatura
  if (filters.minHot !== undefined || filters.maxCold !== undefined) {
    const gameTemp = game.map(n => hotCold.find(h => h.number === n)!);
    const hotCount = gameTemp.filter(t => t.temperature === 'hot').length;
    const coldCount = gameTemp.filter(t => t.temperature === 'cold').length;
    
    if (filters.minHot !== undefined && hotCount < filters.minHot) return false;
    if (filters.maxCold !== undefined && coldCount > filters.maxCold) return false;
  }
  
  return true;
}

/**
 * Gera múltiplos jogos
 */
export function generateMultipleGames(
  draws: Draw[],
  strategy: GenerationStrategy,
  filters: GameFilters,
  count: number
): number[][] {
  const games: number[][] = [];
  const gamesSet = new Set<string>();
  
  let attempts = 0;
  const maxAttempts = count * 100;
  
  while (games.length < count && attempts < maxAttempts) {
    const game = generateGame(draws, strategy, filters);
    const key = game.join(',');
    
    if (!gamesSet.has(key)) {
      games.push(game);
      gamesSet.add(key);
    }
    
    attempts++;
  }
  
  return games;
}

/**
 * Sistema de otimização de cartões (6-20 números)
 */
export function optimizeCards(
  selectedNumbers: number[],
  optimizationLevel: 'complete' | 'optimized' | 'economical' = 'optimized'
): {
  cards: number[][];
  coverage: number;
  totalCost: number;
  technique: string;
} {
  const n = selectedNumbers.length;
  
  if (n < 6) {
    throw new Error('Mínimo de 6 números necessário');
  }
  
  if (n === 6) {
    return {
      cards: [selectedNumbers],
      coverage: 100,
      totalCost: 5.0,
      technique: 'Jogo Simples',
    };
  }
  
  if (optimizationLevel === 'complete') {
    const cards = generateAllCombinations(selectedNumbers, 6);
    return {
      cards,
      coverage: 100,
      totalCost: cards.length * 5.0,
      technique: 'Fechamento Total',
    };
  }
  
  if (optimizationLevel === 'economical') {
    // Minimal cards: just ensure each number appears at least once
    const cards = generateMinimalCards(selectedNumbers);
    const totalCombinations = combinations(n, 6);
    const coverage = (cards.length / totalCombinations) * 100;
    
    return {
      cards,
      coverage,
      totalCost: cards.length * 5.0,
      technique: 'Mínimo de Cartões',
    };
  }
  
  // Optimized: greedy set cover
  const cards = generateOptimizedCards(selectedNumbers);
  const totalCombinations = combinations(n, 6);
  const coverage = Math.min(100, (cards.length / totalCombinations) * 100 * 1.5);
  
  return {
    cards,
    coverage,
    totalCost: cards.length * 5.0,
    technique: 'Sistema Reduzido Otimizado',
  };
}

// Helper functions

function generateAllCombinations(arr: number[], size: number): number[][] {
  if (size > arr.length) return [];
  if (size === arr.length) return [arr];
  if (size === 1) return arr.map(x => [x]);
  
  const result: number[][] = [];
  
  function combine(start: number, chosen: number[]) {
    if (chosen.length === size) {
      result.push([...chosen]);
      return;
    }
    
    for (let i = start; i < arr.length; i++) {
      chosen.push(arr[i]);
      combine(i + 1, chosen);
      chosen.pop();
    }
  }
  
  combine(0, []);
  return result;
}

function generateMinimalCards(numbers: number[]): number[][] {
  const cards: number[][] = [];
  const n = numbers.length;
  const cardsNeeded = Math.ceil(n / 6);
  
  for (let i = 0; i < cardsNeeded; i++) {
    const card: number[] = [];
    for (let j = 0; j < 6; j++) {
      const idx = (i + j * cardsNeeded) % n;
      card.push(numbers[idx]);
    }
    cards.push(card.sort((a, b) => a - b));
  }
  
  return cards;
}

function generateOptimizedCards(numbers: number[]): number[][] {
  const n = numbers.length;
  const targetCards = Math.ceil(combinations(n, 6) * 0.3); // 30% coverage
  const cards: number[][] = [];
  
  // Ensure balanced distribution
  const appearances = new Map<number, number>();
  numbers.forEach(n => appearances.set(n, 0));
  
  for (let i = 0; i < targetCards; i++) {
    const card: number[] = [];
    const available = [...numbers].sort((a, b) => {
      const countA = appearances.get(a) || 0;
      const countB = appearances.get(b) || 0;
      return countA - countB; // Prefer less used numbers
    });
    
    // Select 6 numbers ensuring diversity
    for (let j = 0; j < 6 && j < available.length; j++) {
      const num = available[j];
      card.push(num);
      appearances.set(num, (appearances.get(num) || 0) + 1);
    }
    
    if (card.length === 6) {
      cards.push(card.sort((a, b) => a - b));
    }
  }
  
  return cards;
}

function combinations(n: number, k: number): number {
  if (k > n) return 0;
  if (k === 0 || k === n) return 1;
  
  let result = 1;
  for (let i = 0; i < k; i++) {
    result *= (n - i);
    result /= (i + 1);
  }
  return Math.round(result);
}

function shuffleArray<T>(array: T[]): T[] {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}
