CREATE TABLE `draws` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contest` int NOT NULL,
	`drawDate` timestamp NOT NULL,
	`ball1` int NOT NULL,
	`ball2` int NOT NULL,
	`ball3` int NOT NULL,
	`ball4` int NOT NULL,
	`ball5` int NOT NULL,
	`ball6` int NOT NULL,
	`winners6` int DEFAULT 0,
	`prize` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `draws_id` PRIMARY KEY(`id`),
	CONSTRAINT `draws_contest_unique` UNIQUE(`contest`)
);
